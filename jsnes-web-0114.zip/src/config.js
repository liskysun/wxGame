const config = {
  BASE_ROM_URL: "../roms/",
  GOOGLE_ANALYTICS_CODE: process.env.REACT_APP_GOOGLE_ANALYTICS_CODE,
};

export default config;
