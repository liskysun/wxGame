# JSNES Web UI

A React-based web UI for [JSNES](https://github.com/bfirsh/jsnes).

## Running

    $ yarn install
    $ yarn start

## Running tests

    $ yarn test
